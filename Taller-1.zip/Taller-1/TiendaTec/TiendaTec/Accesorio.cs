﻿using System;
using TiendaTec;
using static System.Runtime.InteropServices.JavaScript.JSType;

public class Accesorio : Producto, IReportable
{
    public string Categoria { get; set; }
    public bool EsGaming { get; set; }

    public Accesorio(int id, string nombre, double precio, int stock, string categoria, bool esGaming)
        : base(id, nombre, precio, stock)
    {
        Categoria = categoria;
        EsGaming = esGaming;
    }

    public override double CalcularPrecioFinal()
    {
        return EsGaming ? Precio * 0.88 : Precio;
    }

    public override void MostrarInfo()
    {
        base.MostrarInfo();
        Console.WriteLine($"Categoría: {Categoria} | Gaming: {EsGaming} | Precio Final: ${CalcularPrecioFinal():F2}");
    }

    public string GenerarReporte()
    {
        return $"[Accesorio] {Nombre} - ${CalcularPrecioFinal():F2} - Stock: {Stock}";
    }
}
