﻿using System;
using TiendaTec;
using static System.Runtime.InteropServices.JavaScript.JSType;

public class Telefono : Producto, IReportable
{
    public string SistemaOperativo { get; set; }
    public int CamaraMP { get; set; }

    public Telefono(int id, string nombre, double precio, int stock, string sistemaOperativo, int camaraMP)
        : base(id, nombre, precio, stock)
    {
        SistemaOperativo = sistemaOperativo;
        CamaraMP = camaraMP;
    }

    public override double CalcularPrecioFinal()
    {
        return CamaraMP >= 50 ? Precio * 0.95 : Precio;
    }

    public override void MostrarInfo()
    {
        base.MostrarInfo();
        Console.WriteLine($"SO: {SistemaOperativo} | Cámara: {CamaraMP}MP | Precio Final: ${CalcularPrecioFinal():F2}");
    }

    public string GenerarReporte()
    {
        return $"[Teléfono] {Nombre} - ${CalcularPrecioFinal():F2} - Stock: {Stock}";
    }
}
