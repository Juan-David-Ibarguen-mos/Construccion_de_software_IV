﻿using System;
using System.Collections.Generic;
using System.Linq;
using TiendaTec;

public class TiendaTech
{
    private List<Producto> productos = new List<Producto>();

    public void AgregarProducto(Producto producto)
    {
        productos.Add(producto);
    }

    public void ListarProductos()
    {
        foreach (var p in productos)
        {
            p.MostrarInfo();
            Console.WriteLine("---------------------------------");
        }
    }

    public Producto BuscarPorId(int id)
    {
        return productos.FirstOrDefault(p => p.Id == id);
    }

    public double CalcularTotalInventario()
    {
        return productos.Sum(p => p.Precio * p.Stock);
    }

    public void GenerarReporteTodos()
    {
        foreach (var p in productos)
        {
            if (p is IReportable reportable)
            {
                Console.WriteLine(reportable.GenerarReporte());
            }
        }
    }
}
