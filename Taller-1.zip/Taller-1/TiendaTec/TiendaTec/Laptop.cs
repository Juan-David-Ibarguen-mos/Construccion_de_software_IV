﻿using System;
using TiendaTec;
using static System.Runtime.InteropServices.JavaScript.JSType;

public class Laptop : Producto, IReportable
{
    public string MarcaGPU { get; set; }
    public int RamGB { get; set; }

    public Laptop(int id, string nombre, double precio, int stock, string marcaGPU, int ramGB)
        : base(id, nombre, precio, stock)
    {
        MarcaGPU = marcaGPU;
        RamGB = ramGB;
    }

    public override double CalcularPrecioFinal()
    {
        return RamGB >= 16 ? Precio * 0.92 : Precio;
    }

    public override void MostrarInfo()
    {
        base.MostrarInfo();
        Console.WriteLine($"GPU: {MarcaGPU} | RAM: {RamGB}GB | Precio Final: ${CalcularPrecioFinal():F2}");
    }

    public string GenerarReporte()
    {
        return $"[Laptop] {Nombre} - ${CalcularPrecioFinal():F2} - Stock: {Stock}";
    }
}
