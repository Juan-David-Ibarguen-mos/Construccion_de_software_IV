﻿public interface IReportable
{
    string GenerarReporte();
}
